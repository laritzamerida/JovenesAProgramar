document.addEventListener("click", function resaltar() {
  // Escribe el código necesario aquí
  let parrafo = document.getElementById("lorem");
  parrafo.classList.toggle("highlight")
  //
});
